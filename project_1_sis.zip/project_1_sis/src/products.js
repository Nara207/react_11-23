export const products = [
    {
        id: 0,
        name: 'Ароматизатор для автомобиля Diamond candle c ароматом "Кожа и древесина"',
        price: 335,
        imagePath: 'public/card_img.png',
    },
    {
        id: 1,
        name: 'Держатель для телефона автомобильный телескопический раздвижной',
        price: 444,
        imagePath: 'public/card_img1.png',
    },
    {
        id: 2,
        name: 'Ароматизатор для автомобиля Diamond candle c ароматом "Кожа и древесина"',
        price: 335,
        imagePath: 'public/card_img.png',
    },
    {
        id: 3,
        name: 'Держатель для телефона автомобильный телескопический раздвижной',
        price: 444,
        imagePath: 'public/card_img1.png',
    },
    {
        id: 4,
        name: 'Ароматизатор для автомобиля Diamond candle c ароматом "Кожа и древесина"',
        price: 335,
        imagePath: 'public/card_img.png',
    },
    {
        id: 5,
        name: 'Держатель для телефона автомобильный телескопический раздвижной',
        price: 444,
        imagePath: 'public/card_img1.png',
    },
]